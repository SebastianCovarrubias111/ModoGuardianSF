package com.example.insertcode.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

// Declaración del DataStore (Mantenemos tu nombre actual)
val Context.dataStore by preferencesDataStore(name = "preferences_usuario")

class EstadoDataStore(private val context: Context) {

    private val estadoActivado = booleanPreferencesKey("modo_activado")

    // Tu función original
    suspend fun guardarEstado(valor: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[estadoActivado] = valor
        }
    }

    // Tu función original
    fun obtenerEstado(): Flow<Boolean> {
        return context.dataStore.data
            .catch { exception ->
                if (exception is IOException) {
                    emit(emptyPreferences())
                } else {
                    throw exception
                }
            }
            .map { preferences ->
                preferences[estadoActivado] ?: false
            }
    }
    /*
       AGREGAMOS ESTOS CAMPOS COMO ALIAS:
       Así mantienes tu lógica intacta y tu ViewModel podrá compilar
       utilizando los nombres exactos que exige la Guía 14.
    */
    val modoEspecialFlow: Flow<Boolean> = obtenerEstado()

    suspend fun guardarModoEspecial(value: Boolean) {
        guardarEstado(value)
    }
}