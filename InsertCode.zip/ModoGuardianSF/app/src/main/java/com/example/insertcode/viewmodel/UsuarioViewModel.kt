package com.example.insertcode.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.insertcode.data.UsuarioDao
import com.example.insertcode.data.UsuarioEntity
import com.example.insertcode.model.UsuarioErrores
import com.example.insertcode.model.UsuarioUiState
import com.example.insertcode.repository.EstadoDataStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Date

class UsuarioViewModel(
    private val usuarioDao: UsuarioDao,
    private val preferencesManager: EstadoDataStore
) : ViewModel() {

    // Estado interno mutable
    private val _estado = MutableStateFlow(UsuarioUiState())
    // Estado expuesto para la UI
    val estado: StateFlow<UsuarioUiState> = _estado.asStateFlow()

    // Nuevos estados requeridos para el flujo de la Guía 14
    private val _cargando = MutableStateFlow(true)
    val cargando: StateFlow<Boolean> = _cargando.asStateFlow()

    private val _mensajeExito = MutableStateFlow<String?>(null)
    val mensajeExito: StateFlow<String?> = _mensajeExito.asStateFlow()

    init {
        // Simular carga inicial y observar DataStore de modo premium (Parte 2)
        viewModelScope.launch {
            delay(1500)
            _cargando.value = false

            preferencesManager.modoEspecialFlow.collect { modo ->
                _estado.update { it.copy(modoEspecial = modo) }
            }
        }
    }

    // Actualiza el campo nombre y limpia su error
    fun onNombreChange(valor: String) {
        _estado.update { it.copy(nombre = valor, errores = it.errores.copy(nombre = null)) }
    }

    // Actualiza el campo correo
    fun onCorreoChange(valor: String) {
        _estado.update { it.copy(correo = valor, errores = it.errores.copy(correo = null)) }
    }

    // Actualiza el campo clave
    fun onClaveChange(valor: String) {
        _estado.update { it.copy(clave = valor, errores = it.errores.copy(clave = null)) }
    }

    // Actualiza el campo direccion
    fun onDireccionChange(valor: String) {
        _estado.update { it.copy(direccion = valor, errores = it.errores.copy(direccion = null)) }
    }

    // Actualiza checkbox de aceptación
    fun onAceptarTerminosChange(valor: Boolean) {
        _estado.update { it.copy(aceptarTerminos = valor) }
    }

    // Actualiza la URI de la foto (Agregado para manejo de Cámara/Galería)
    fun actualizarFoto(uri: Uri?) {
        _estado.update { it.copy(fotoUri = uri) }
    }

    // Invierte el modo premium, guarda en DataStore y muestra un mensaje por 2 segundos (Parte 3)
    fun toggleModoEspecial() {
        viewModelScope.launch {
            val nuevoModo = !_estado.value.modoEspecial
            preferencesManager.guardarModoEspecial(nuevoModo)
            _mensajeExito.value = "¡Modo Premium Actualizado!"
            delay(2000)
            _mensajeExito.value = null
        }
    }

    // Validación global del formulario (Actualizada con los criterios de la Guía 14)
    fun validarFormulario(): Boolean {
        val estadoActual = _estado.value
        val errores = UsuarioErrores(
            nombre = if (estadoActual.nombre.length < 3) "Mínimo 3 caracteres" else null,
            correo = if (!estadoActual.correo.contains("@")) "Correo inválido (falta @)" else null,
            clave = if (estadoActual.clave.length < 6) "Mínimo 6 caracteres" else null,
            direccion = if (estadoActual.direccion.isBlank()) "La dirección es obligatoria" else null,
            aceptaTerminos = if (!estadoActual.aceptarTerminos) "Debe aceptar los términos" else null,
            fotoUri = if (estadoActual.fotoUri == null) "Debe seleccionar una foto" else null
        )

        val hayErrores = listOfNotNull(
            errores.nombre,
            errores.correo,
            errores.clave,
            errores.direccion,
            errores.aceptaTerminos,
            errores.fotoUri
        ).isNotEmpty()

        _estado.update { it.copy(errores = errores) }

        return !hayErrores
    }

    // Convierte el estado actual y lo persiste de manera local en ROOM (Parte 3)
    fun guardarEnRoom(onSuccess: () -> Unit) {
        if (validarFormulario()) {
            viewModelScope.launch {
                val estadoActual = _estado.value
                val entity = UsuarioEntity(
                    nombre = estadoActual.nombre,
                    correo = estadoActual.correo,
                    direccion = estadoActual.direccion,
                    modoEspecial = estadoActual.modoEspecial,
                    fotoPath = estadoActual.fotoUri?.toString(),
                    fechaRegistro = Date()
                )
                usuarioDao.insertar(entity)
                onSuccess()
            }
        }
    }
}