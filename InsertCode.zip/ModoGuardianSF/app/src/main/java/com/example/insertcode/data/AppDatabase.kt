package com.example.insertcode.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map

abstract class AppDatabase {
    abstract fun usuarioDao(): UsuarioDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val listaUsuariosLocal = MutableStateFlow<List<UsuarioEntity>>(emptyList())

                val instance = object : AppDatabase() {
                    override fun usuarioDao(): UsuarioDao = object : UsuarioDao {
                        override fun getUsuariosFlow(): Flow<List<UsuarioEntity>> = listaUsuariosLocal

                        override suspend fun getPorId(id: Int): UsuarioEntity? {
                            return listaUsuariosLocal.value.find { it.id == id }
                        }

                        override suspend fun insertar(usuario: UsuarioEntity) {
                            val nuevaLista = listaUsuariosLocal.value.toMutableList()
                            val usuarioConId = usuario.copy(id = nuevaLista.size + 1)
                            nuevaLista.add(usuarioConId)
                            listaUsuariosLocal.value = nuevaLista
                        }

                        override suspend fun eliminar(usuario: UsuarioEntity) {
                            val nuevaLista = listaUsuariosLocal.value.toMutableList()
                            nuevaLista.removeIf { it.id == usuario.id }
                            listaUsuariosLocal.value = nuevaLista
                        }

                        override fun buscarPorCorreo(query: String): Flow<List<UsuarioEntity>> {
                            return listaUsuariosLocal.map { lista ->
                                lista.filter { it.correo.contains(query, ignoreCase = true) }
                            }
                        }
                    }
                }
                INSTANCE = instance
                instance
            }
        }
    }
}