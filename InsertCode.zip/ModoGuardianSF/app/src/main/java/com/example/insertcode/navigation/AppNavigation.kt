package com.example.insertcode.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.insertcode.ui.theme.screen.HomeAdminScreen
import com.example.insertcode.ui.theme.screen.HomeOperatorScreen
import com.example.insertcode.ui.theme.screen.HomeSupervisorScreen
import com.example.insertcode.ui.theme.screen.LoginScreen
import com.example.insertcode.ui.theme.screen.PantallaPrincipal
import com.example.insertcode.ui.theme.screen.PerfilScreen
import com.example.insertcode.ui.theme.screen.RegistroScreen
import com.example.insertcode.ui.theme.screen.ResumenScreen
import com.example.insertcode.ui.theme.screen.ListadoOfflineScreen
import com.example.insertcode.viewmodel.EstadoViewModel
import com.example.insertcode.viewmodel.LoginViewModel
import com.example.insertcode.viewmodel.PerfilViewModel
import com.example.insertcode.viewmodel.UsuarioViewModel
import com.example.insertcode.data.UsuarioDao

// 1. Definición de las pantallas del sistema (Sealed Class extendida con Guía 14)
sealed class Screen(val route: String) {
    data object Login : Screen("login")
    data object HomeAdmin : Screen("home_admin")
    data object HomeSupervisor : Screen("home_supervisor")
    data object HomeOperator : Screen("home_operator")
    data object AnimacionesEstados : Screen("animaciones_estados")
    data object Perfil : Screen("perfil")

    // Rutas añadidas para la Guía 14
    data object Registro : Screen("registro")
    data object Resumen : Screen("resumen")
    data object Listado : Screen("listado")
}

// 2. Eventos de navegación reactiva despachados por el ViewModel
sealed class NavigationEvent {
    data class NavigateTo(val route: String) : NavigationEvent()
    data object NavigateBack : NavigationEvent()
}

@Composable
fun AppNavigation(
    navController: NavHostController,
    loginViewModel: LoginViewModel,
    estadoViewModel: EstadoViewModel,
    perfilViewModel: PerfilViewModel,
    usuarioViewModel: UsuarioViewModel, // Agregado para Guía 14
    usuarioDao: UsuarioDao,             // Agregado para lectura directa en Listado
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Login.route,
        modifier = modifier
    ) {
        // Pantalla de Login Principal
        composable(route = Screen.Login.route) {
            LoginScreen(viewModel = loginViewModel)
        }

        // Pantalla de Inicio para el Rol Administrador
        composable(route = Screen.HomeAdmin.route) {
            HomeAdminScreen(viewModel = loginViewModel, navController = navController)
        }

        // Pantalla de Inicio para el Rol Supervisor
        composable(route = Screen.HomeSupervisor.route) {
            HomeSupervisorScreen(viewModel = loginViewModel, navController = navController)
        }

        // Pantalla de Inicio para el Rol Operador
        composable(route = Screen.HomeOperator.route) {
            HomeOperatorScreen(viewModel = loginViewModel, navController = navController)
        }

        // Pantalla asociada a la Guía 12 (Animaciones y Estados)
        composable(route = Screen.AnimacionesEstados.route) {
            PantallaPrincipal(viewModel = estadoViewModel)
        }

        // Pantalla asociada a la Guía 13 (Cámara y Galería)
        composable(route = Screen.Perfil.route) {
            PerfilScreen(viewModel = perfilViewModel)
        }

        // ==========================================
        // CONFIGURACIÓN DE RUTAS - GUÍA 14
        // ==========================================

        // Destino 1: Formulario de Registro Integral
        composable(route = Screen.Registro.route) {
            RegistroScreen(
                navController = navController,
                viewModel = usuarioViewModel
            )
        }

        // Destino 2: Resumen del Usuario Creado
        composable(route = Screen.Resumen.route) {
            ResumenScreen(
                navController = navController,
                viewModel = usuarioViewModel
            )
        }

        // Destino 3: Listado Histórico Offline desde ROOM
        composable(route = Screen.Listado.route) {
            ListadoOfflineScreen(
                navController = navController,
                usuarioDao = usuarioDao
            )
        }
    }
}