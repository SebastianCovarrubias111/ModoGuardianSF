package com.example.insertcode.ui.theme.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.insertcode.ui.ImagenInteligente
import com.example.insertcode.ui.PremiumCard
import com.example.insertcode.viewmodel.UsuarioViewModel

@Composable
fun ResumenScreen(
    navController: NavController,
    viewModel: UsuarioViewModel
) {
    // Observamos el estado expuesto por el mismo ViewModel de manera reactiva
    val estado by viewModel.estado.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(all = 16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Resumen del Registro",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.fillMaxWidth()
        )

        // ========== COMPONENTE FOTO CAPTURADA (Guía 14) ==========
        ImagenInteligente(fotoUri = estado.fotoUri)

        Spacer(modifier = Modifier.height(4.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = "Nombre: ${estado.nombre}", style = MaterialTheme.typography.bodyLarge)
            Text(text = "Correo: ${estado.correo}", style = MaterialTheme.typography.bodyLarge)
            Text(text = "Dirección: ${estado.direccion}", style = MaterialTheme.typography.bodyLarge)

            // Muestra la contraseña enmascarada con asteriscos según su longitud
            Text(text = "Contraseña: ${"*".repeat(estado.clave.length)}", style = MaterialTheme.typography.bodyLarge)

            // Muestra si aceptó o no los términos condicionalmente
            Text(text = "Términos: ${if (estado.aceptarTerminos) "Aceptados" else "No aceptados"}", style = MaterialTheme.typography.bodyLarge)
        }

        // ========== CARD ANIMADA DE BENEFICIOS (Guía 14) ==========
        PremiumCard(visible = estado.modoEspecial)

        Spacer(modifier = Modifier.height(12.dp))

        // ========== BOTÓN PARA IR AL LISTADO HISTÓRICO DE ROOM (Guía 14) ==========
        Button(
            onClick = { navController.navigate("listado") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Ver Historial de Usuarios (ROOM)")
        }
    }
}