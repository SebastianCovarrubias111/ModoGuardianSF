package com.example.insertcode.ui.theme.screen

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.insertcode.data.UsuarioEntity
import com.example.insertcode.ui.ImagenInteligente

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListadoOfflineScreen(
    navController: NavController,
    usuarioDao: com.example.insertcode.data.UsuarioDao
) {
    // Estado local para mantener la lista recuperada de ROOM con imports correctos
    var listaUsuarios by remember { mutableStateOf<List<UsuarioEntity>>(emptyList()) }

    // Escucha el flujo offline de ROOM de forma segura al entrar a la pantalla
    LaunchedEffect(Unit) {
        usuarioDao.getUsuariosFlow().collect { lista ->
            listaUsuarios = lista
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Historial Offline (ROOM)") }) }
    ) { paddingValues ->
        if (listaUsuarios.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Text("No hay usuarios registrados localmente.", style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Usamos items pasándole la colección real para que reconozca el tipo de objeto
                items(listaUsuarios) { usuario ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Carga la foto persistida desde su ruta String reconstruyendo la URI
                            val fotoUri = usuario.fotoPath?.let { Uri.parse(it) }
                            ImagenInteligente(fotoUri = fotoUri, modifier = Modifier.size(64.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = usuario.nombre, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text(text = usuario.correo, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
                                if (usuario.modoEspecial) {
                                    Text(text = "✨ Miembro Premium", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}