package com.example.insertcode.model

import android.net.Uri

data class UsuarioUiState(
    val nombre: String = "",
    val correo: String = "",
    val clave: String = "",
    val direccion: String = "",
    val aceptarTerminos: Boolean = false,
    val fotoUri: Uri? = null,         // Agregado para Cámara y Galería
    val modoEspecial: Boolean = false, // Agregado para Modo Premium
    val errores: UsuarioErrores = UsuarioErrores()
)

data class UsuarioErrores(
    val nombre: String? = null,
    val correo: String? = null,
    val clave: String? = null,
    val direccion: String? = null,
    val aceptaTerminos: String? = null, // Agregado para validación de TyC
    val fotoUri: String? = null        // Agregado para validación de Foto
)