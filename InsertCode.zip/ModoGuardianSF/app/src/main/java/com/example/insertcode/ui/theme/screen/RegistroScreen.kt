package com.example.insertcode.ui.theme.screen

import android.net.Uri
import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import com.example.insertcode.ui.ImagenInteligente
import com.example.insertcode.ui.PremiumCard
import com.example.insertcode.viewmodel.UsuarioViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RegistroScreen(
    navController: NavController,
    viewModel: UsuarioViewModel
) {
    val context = LocalContext.current

    // Observamos los flujos de estado del ViewModel (Parte 2 y 5)
    val estado by viewModel.estado.collectAsState()
    val cargando by viewModel.cargando.collectAsState()
    val mensajeExito by viewModel.mensajeExito.collectAsState()

    // Control temporal para almacenar la URI generada por la cámara
    var camaraUriTmp by rememberSaveable { mutableStateOf<Uri?>(null) }

    // Lanzador para la Galería (Parte 5)
    val galeriaLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.actualizarFoto(uri)
        }
    }

    // Lanzador para la Cámara (Parte 5)
    val camaraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { exito: Boolean ->
        if (exito && camaraUriTmp != null) {
            viewModel.actualizarFoto(camaraUriTmp)
        }
    }

    // Función auxiliar para crear el archivo temporal de la foto
    fun crearArchivoTemporalUri(): Uri {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val archivo = File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir)
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            archivo
        )
    }

    // Loader Inicial Simulado (Parte 2)
    if (cargando) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(all = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // ========== IMAGEN INTELIGENTE (Parte 5) ==========
            ImagenInteligente(fotoUri = estado.fotoUri)

            estado.errores.fotoUri?.let {
                Text(
                    text = it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // ========== BOTONES NATIVOS (Parte 5) ==========
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(onClick = {
                    val uri = crearArchivoTemporalUri()
                    camaraUriTmp = uri
                    camaraLauncher.launch(uri)
                }) {
                    Text("Cámara")
                }
                Button(onClick = {
                    galeriaLauncher.launch("image/*")
                }) {
                    Text("Galería")
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // ========== CAMPO NOMBRE ==========
            OutlinedTextField(
                value = estado.nombre,
                onValueChange = viewModel::onNombreChange,
                label = { Text(text = "Nombre") },
                isError = estado.errores.nombre != null,
                supportingText = {
                    estado.errores.nombre?.let {
                        Text(text = it, color = MaterialTheme.colorScheme.error)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            // ========== CAMPO CORREO ==========
            OutlinedTextField(
                value = estado.correo,
                onValueChange = viewModel::onCorreoChange,
                label = { Text(text = "Correo electrónico") },
                isError = estado.errores.correo != null,
                supportingText = {
                    estado.errores.correo?.let {
                        Text(text = it, color = MaterialTheme.colorScheme.error)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            // ========== CAMPO CLAVE ==========
            OutlinedTextField(
                value = estado.clave,
                onValueChange = viewModel::onClaveChange,
                label = { Text(text = "Contraseña") },
                visualTransformation = PasswordVisualTransformation(),
                isError = estado.errores.clave != null,
                supportingText = {
                    estado.errores.clave?.let {
                        Text(text = it, color = MaterialTheme.colorScheme.error)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            // ========== CAMPO DIRECCIÓN ==========
            OutlinedTextField(
                value = estado.direccion,
                onValueChange = viewModel::onDireccionChange,
                label = { Text(text = "Dirección") },
                isError = estado.errores.direccion != null,
                supportingText = {
                    estado.errores.direccion?.let {
                        Text(text = it, color = MaterialTheme.colorScheme.error)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            // ========== CHECKBOX ACEPTAR TÉRMINOS ==========
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = estado.aceptarTerminos,
                    onCheckedChange = viewModel::onAceptarTerminosChange
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Acepto los términos y condiciones")
            }
            estado.errores.aceptaTerminos?.let {
                Text(
                    text = it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // ========== BOTÓN MODO PREMIUM ANIMADO (Parte 2 y 5) ==========
            val premiumButtonColor by animateColorAsState(
                targetValue = if (estado.modoEspecial) Color(0xFF2E7D32) else Color.Gray,
                label = "ColorPremiumAnim"
            )

            val textoPremiumDerivado = remember(estado.modoEspecial) {
                derivedStateOf { if (estado.modoEspecial) "Premium Activado ✨" else "Activar Modo Premium" }
            }

            Button(
                onClick = { viewModel.toggleModoEspecial() },
                colors = ButtonDefaults.buttonColors(containerColor = premiumButtonColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(textoPremiumDerivado.value)
            }

            // ========== CARD ANIMADA (Parte 4) ==========
            PremiumCard(visible = estado.modoEspecial)

            // ========== FEEDBACK VISUAL MENSAJE DATASTORE (Parte 2) ==========
            AnimatedVisibility(visible = mensajeExito != null) {
                mensajeExito?.let {
                    Text(
                        text = it,
                        color = Color(0xFF2E7D32),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ========== BOTÓN REGISTRAR EN ROOM Y NAVEGAR ==========
            Button(
                onClick = {
                    // Guarda de forma persistente en ROOM y ejecuta la navegación si la validación es exitosa
                    viewModel.guardarEnRoom {
                        navController.navigate("resumen")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Registrar y ver Resumen")
            }
        }
    }
}